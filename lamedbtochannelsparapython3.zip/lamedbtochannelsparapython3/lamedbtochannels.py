#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys, unicodedata, re, os, glob, zipfile, time, datetime, gzip

def main():
    lamedb = "/etc/enigma2/lamedb"
    piconLocations = ["/usr/share/enigma2/picon/", "/picon/", "/media/usb/picon/", "/media/usb2/picon/",
                      "/media/hdd/picon/", "/media/hdd2/picon/", "/media/cf/picon/", "/media/sdb/picon/",
                      "/media/sdb2/picon/", "/media/sda/picon/", ]
    canaisxml = "/tmp/.canais.xml"
    outlog1 = ".found-picons"
    outlog2 = "ch"
    outlog3 = ".impossible-picons"
    logExt = ".xml"
    piconOutFolder = "/picon/"
    messages1 = []
    messages2 = {}
    messages3 = []
    messages = []
    paths = []
    pattern = "*.png"
    serviceTypes = []

    print("PROCURANDO CANAIS E REFERENCIAS...")

    for l in piconLocations:
        paths += glob.glob(l + pattern)
    pathsSplit = []
    for p in paths:
        pathsSplit.append(p.rsplit('/', 1))
    del paths
    paths = {}

    print("Processando Arquivos...")

    for p in pathsSplit:
        f = p[0] + '/' + p[1]
        n = p[1]
        if os.path.islink(f):
            f = p[0] + '/' + os.readlink(f)
            if os.path.exists(f):
                paths[n] = f
        else:
            paths[n] = f
    del pathsSplit

    with open(lamedb, 'r') as file:
        f = file.readlines()
    f = f[f.index("services\n")+1:-3]
    i = 0
    done = []
    arquivo = open(canaisxml, 'w')

    while len(f) > 2:
        ref = [x for x in f[0][:-1].split(':')]
        name = f[1][:-1]
        f = f[3:]
        slot = slot1(ref[1])
        sat = slot1(ref[1])
        refstr = "1:0:1:%x:%x:%x:%x:0:0:0" % (int(ref[0], 16), int(ref[2], 16), int(ref[3], 16), int(ref[1], 16))
        serviceType = str(hex(int(ref[4]))).replace('0x', '')
        refstr2 = "1:0:%s:%x:%x:%x:%x:0:0:0" % (serviceType, int(ref[0], 16), int(ref[2], 16), int(ref[3], 16), int(ref[1], 16))
        oldPiconName = refstr + "</channel>"
        oldPiconName2 = refstr2

        Nomes1 = unicodedata.normalize('NFC', name).encode('ASCII', 'ignore').decode('ASCII').replace("MTV's 00", 'MTV00').replace(' HD', '').replace('&', '').replace('', '').replace(' ', '').replace('/', '').replace('-', '').replace('', '').replace('.', '').replace('(', '').replace(')', '').replace('+', 'PLUS').replace('!', '').replace('  ', ' ').upper()
        Nomes2 = unicodedata.normalize('NFC', name).replace('&', '&amp;').replace('', '').replace('  ', ' ')
        Nomes3 = unicodedata.normalize('NFC', name).replace('&', '&amp;').replace('', '').replace('  ', ' ')
        newName1 = unicodedata.normalize('NFC', name).replace('&', '&amp;').replace('', '').replace('  ', ' ')
        newName2 = unicodedata.normalize('NFC', name).replace('&', '&amp;').replace('', '').replace('  ', ' ')

        newPiconName = newName1

        if int(ref[4]) < 26:
            if (len(newName2) and newPiconName in paths) or oldPiconName in paths or oldPiconName2 in paths:
                finished = True
            else:
                messages.append((Nomes1, newPiconName, oldPiconName2, Nomes3, sat, int(ref[4])))
            i += 1
            if i % 100 == 0:
                print(f"Lendo {i} Canais... Encontrados ")

            serviceTypes.append(int(ref[4]))

    messages = (messages)

    i = 0
    log1 = ''
    for message in messages:
        if i % 25 == 0:
            log1 += ''
        log1 += '\t\t<channel id="%s">%s:</channel> <!-- %s - %s -->\n' % (message[0], message[2], message[3], message[4])
        i += 1

    arquivo.write(log1)
    arquivo.close()

    print('SOURCE GERADO ARQUIVO > /etc/enigma2/channels.xml.gz')

    if not os.path.isfile("/tmp/nomes") and not os.path.isdir("/tmp/nomes"):
        os.mkdir("/tmp/nomes")
    os.system("ls &> /dev/null")
    finished = True

    print("FINALIZANDO...")

    LER1 = canaisxml
    GERADO = '/tmp/.canais2.xml'
    REMOVER = ['<channel id="">', 'Teste', 'Radio', 'Anos', 'Hab', 'Classica', 'Blues', 'Sertanejo', 'Festa Junina',
               'Jazz', 'Bossa Nova', 'New Rock', 'Romanticas', 'Trilhas Sonoras', 'Lounge', 'Gospel', 'Forro',
               'Teletema', 'Samba', 'POP Hits', 'Hip Hop', 'Pop Hits', 'Eletronica', 'Reggae', 'Rock Brasil',
               'Roberto Carlos', 'ISDB-T', 'Banda C','Soft Hits','Funk e Rap','BH FM', 'TVEXEC', 'TVTEC', 'Metal', 'MPB', 'PVR','Festa', 'Rock Classico','Classica','Pagode', 'Musica', 'Divas', 'Soft hits', 'FM Express', 'CBN SP', 'Band News FM', 'Nativa FM', 'Band FM', 'Michael Jackson', '1SEG', 'Madonna', '"Disco"',
               '"Kids"','>1:0:2:']
    with open(LER1) as oldfile, open(GERADO, 'w+') as newfile:
        for line in oldfile:
            if not any(bad_word in line for bad_word in REMOVER):
                newfile.write(line
                              .replace('2429', '(117w-C)')
                              .replace('2469', '(113w-C)')
                              .replace('2710', '(89-ku)')
                              .replace('2760', '(84w-C)')
                              .replace('2849', '(75w-C)')
                              .replace('2899', '(70w-C)')
                              .replace('2900', '(CLARO DTH)')
                              .replace('Mudar n�mero', '(Planejada - 65w-C)')
                              .replace('2949', '(65w-C)')
                              .replace('Mudar n�mero 2','( Planejada - 61w-C)')
                              .replace('2989','(61w-C)')
                              .replace('2990', '(VIVO AMAZONAS)')
                              .replace('3019', '(58w-C)')
                              .replace('3044', '(55.5w-C)')
                              .replace('3124', '(47.5w-C)')
                              .replace('3149', '(45w-C)')
                              .replace('3168', '(43w-C)')
                              .replace('3169', '(SKY HDTV)')
                              .replace('3193','(Planejada - 40.5w-C)')
                              .replace('3194','(40.5w-C)')
                              .replace('3224', '(37.5w-C)')
                              .replace('3254', '(34.5w-C)')
                              .replace('3379','(22w-C)')
                              .replace('3419','(18w-C)')
                              .replace('3459', '(14w-C)')
                              .replace('3489', '(11w-C)')
                              .replace('3519', '(8w-C)')
                              .replace('3569', '(3w-C)')
                              .replace('3570', '(3w-ku)')
                              .replace('65535', 'NET TV')
                              .replace('61166', '(ISDB-T)')
                              .replace(' ">', '">'))

    from datetime import datetime
    datahoje = datetime.now().strftime('Gerado em %d/%m/%Y  %H:%M:%S')
    LERCABE = '/tmp/.cabecalho.xml'
    with open(LERCABE,"w+") as CABECA1:
        CABECA1.write('<?xml version="1.0" encoding="latin-1"?>\n\t<!-- %s -->\n\t<channels>\n' % datahoje)

    filenames = ['/tmp/.cabecalho.xml', '/tmp/.canais2.xml']
    os.system("rm /etc/enigma2/channels.xml.gz &> /dev/null")
    os.system("rm /etc/enigma2/channels.xml &> /dev/null")
    with open('/tmp/channels.xml', 'w+') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                for line in infile:
                    outfile.write(line)

    with open('/tmp/channels.xml', "a+") as GRAVAR:
        GRAVAR.write('\t</channels>')

    os.system("cp /tmp/channels.xml /etc/enigma2/ &> /dev/null")
    os.system("gzip -k /etc/enigma2/channels.xml &> /dev/null")
    print("OK")

def slotName(namespace):
    slot = slot1(namespace)
    return satname(slot)

def satname(slot):
    if slot == 65535:
        return 'cable'
    elif slot == 61166:
        return 'terrestrial'
    while slot < -1800:
        slot += 3600
    while slot > 1800:
        slot -= 3600
    westeast = 'E' if slot >= 0 else 'W'
    return str(round(float(abs(slot)) / 10, 1)) + westeast

def slot1(namespace):
    return int(namespace[:len(namespace) - 4], 16)

if __name__ == '__main__':
    main()
